#' Title
#'
#' @return
#' @export
#'
#' @examples
pkg_sqlite <- function() {
  pacman::p_load("DBI",
                 "RSQLite",
                 "tidyverse")
}
