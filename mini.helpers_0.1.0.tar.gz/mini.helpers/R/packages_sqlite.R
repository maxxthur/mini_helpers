#' Title
#'
#' @return
#' @export
#'
#' @examples
pkg_sqlite <- function() {
  p_load("DBI",
                 "RSQLite",
                 "tidyverse")
}
