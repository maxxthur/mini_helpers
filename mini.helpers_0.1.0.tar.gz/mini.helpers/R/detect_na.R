#' Title
#'
#' @param x
#'
#' @return
#' @export
#'
#' @examples
na_detect <- function(x) {
  x %>%
    filter_all(any_vars(is.na(.)))
}
