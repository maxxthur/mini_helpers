#' Title
#'
#' @return
#' @export
#'
#' @examples
pkg_excel <- function() {
  pacman::p_load("readxl",
                 "writexl",
                 "openxlsx",
                 "tidyxl")
}
